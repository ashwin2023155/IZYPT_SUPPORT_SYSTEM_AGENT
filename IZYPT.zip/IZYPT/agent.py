"""
Main IZYPT Chatbot Agent
Integrates Gemini API, database tools, and conversation management
"""
import re
from typing import Dict, Optional, Tuple
import config

# Use Gemini API or local LLM based on config
if config.USE_GEMINI_API:
    from gemini_agent import get_gemini_agent
else:
    from llm.loader import load_llm

import database_tools
from conversation_manager import conversation_manager


class IZYPTAgent:
    """Main chatbot agent for IZYPT customer service and sales"""
    
    def __init__(self):
        """Initialize the agent and load the model"""
        if config.USE_GEMINI_API:
            print("[Agent] Using Gemini API")
            self.gemini = get_gemini_agent()
            self.model = None
            self.tokenizer = None
        else:
            print("[Agent] Loading local LLM model...")
            self.model, self.tokenizer = load_llm()
            self.gemini = None
            print("[Agent] LLM model loaded successfully")
    
    def _extract_search_params(self, message: str) -> Dict:
        """
        Extract search parameters from user message
        
        Args:
            message: User message
        
        Returns:
            Dictionary with extracted parameters
        """
        params = {}
        
        # Extract phone number (10 digits, handling spaces and various formats)
        # Remove all spaces first for better matching
        message_no_spaces = message.replace(' ', '')
        phone_match = re.search(r'\b\d{10}\b', message_no_spaces)
        if phone_match:
            params['phone'] = phone_match.group()
        
        # Also try with spaces (Twilio transcription often adds spaces)
        if 'phone' not in params:
            phone_match_spaces = re.search(r'\b\d{3}\s?\d{3}\s?\d{4}\b', message)
            if phone_match_spaces:
                params['phone'] = phone_match_spaces.group().replace(' ', '')
        
        # Extract order ID
        order_match = re.search(r'#?ORD[-\d]+', message, re.IGNORECASE)
        if order_match:
            params['order_id'] = order_match.group()
        
        return params
    
    def _search_database(self, message: str) -> Optional[str]:
        """
        Search database based on message content
        
        Args:
            message: User message
        
        Returns:
            Formatted database results or None
        """
        params = self._extract_search_params(message)
        
        # Try order ID first
        if 'order_id' in params:
            order = database_tools.search_order_by_id(params['order_id'])
            if order:
                return database_tools.format_order_for_llm(order)
        
        # Try phone number
        if 'phone' in params:
            orders = database_tools.search_orders_by_phone(params['phone'])
            if orders:
                return database_tools.format_orders_summary(orders)
        
        # Check if message contains keywords that need database lookup
        lookup_keywords = ['order', 'status', 'delivery', 'track', 'check', 'find']
        message_lower = message.lower()
        
        if any(keyword in message_lower for keyword in lookup_keywords):
            # Try to find phone number in message
            if 'phone' in params:
                orders = database_tools.search_orders_by_phone(params['phone'])
                if orders:
                    return database_tools.format_orders_summary(orders)
        
        return None
    
    def _generate_response(self, prompt: str, max_tokens: int = None) -> str:
        """
        Generate response from LLM (Gemini or local model)
        
        Args:
            prompt: Full prompt with history
            max_tokens: Maximum tokens to generate
        
        Returns:
            Generated response text
        """
        if max_tokens is None:
            max_tokens = config.CHAT_MAX_TOKENS
        
        if config.USE_GEMINI_API:
            # Use Gemini API
            response = self.gemini.generate(prompt, max_tokens)
            return response
        else:
            # Use local LLM
            inputs = self.tokenizer(prompt, return_tensors="pt").to(self.model.device)
            
            output = self.model.generate(
                **inputs,
                max_new_tokens=max_tokens,
                temperature=config.TEMPERATURE,
                do_sample=True,
                pad_token_id=self.tokenizer.eos_token_id
            )
            
            full_text = self.tokenizer.decode(output[0], skip_special_tokens=True)
            
            # Extract only the assistant's response (remove the prompt)
            if "Assistant:" in full_text:
                parts = full_text.split("Assistant:")
                response = parts[-1].strip()
            else:
                response = full_text[len(prompt):].strip()
            
            # Clean up for voice mode
            if max_tokens == config.VOICE_MAX_TOKENS:
                response = response.split("User:")[0].strip()
                response = response.split("Assistant:")[0].strip()
                sentences = [s.strip() for s in response.split('.') if s.strip()]
                if sentences:
                    response = sentences[0] + '.'
            
            return response
    
    def chat(self, message: str, session_id: Optional[str] = None, mode: str = "support") -> Tuple[str, str, Optional[Dict]]:
        """
        Process a chat message and return response
        
        Args:
            message: User message
            session_id: Optional session ID for multi-turn conversation
            mode: Agent mode - "support", "sales", or "voice"
        
        Returns:
            Tuple of (session_id, response, database_info)
        """
        # Create or get session
        if session_id is None or session_id not in conversation_manager.sessions:
            session_id = conversation_manager.create_session(session_id, mode)
        
        # Search database if needed
        db_info = self._search_database(message)
        
        # Add user message to history
        conversation_manager.add_message(session_id, "user", message)
        
        # Build prompt with context
        prompt = conversation_manager.get_formatted_history(session_id)
        
        # If we found database info, inject it into the prompt
        if db_info:
            prompt = prompt.rstrip() + f"\n\n[Database Information]\n{db_info}\n\nUse the above information to answer the user's question.\n\nAssistant: "
        
        # Determine max tokens based on mode
        max_tokens = config.VOICE_MAX_TOKENS if mode == "voice" else config.CHAT_MAX_TOKENS
        
        # Generate response
        response = self._generate_response(prompt, max_tokens)
        
        # Add assistant response to history
        conversation_manager.add_message(session_id, "assistant", response)
        
        # Return results
        db_dict = {"info": db_info} if db_info else None
        return session_id, response, db_dict
    
    def clear_session(self, session_id: str):
        """Clear a conversation session"""
        conversation_manager.clear_session(session_id)
    
    def get_session_history(self, session_id: str):
        """Get conversation history for a session"""
        return conversation_manager.get_history(session_id)


# Global agent instance (singleton pattern - load model once)
_agent_instance = None

def get_agent() -> IZYPTAgent:
    """Get the global agent instance (creates it if needed)"""
    global _agent_instance
    if _agent_instance is None:
        _agent_instance = IZYPTAgent()
    return _agent_instance
