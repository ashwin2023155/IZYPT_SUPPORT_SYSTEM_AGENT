# Quick Gemini API Test
import google.generativeai as genai

API_KEY = "AIzaSyB4JsYelP_Q2h8WkGeYzZeVMO2curIPf8U"

genai.configure(api_key=API_KEY)

# List available models
print("Available models:")
for m in genai.list_models():
    if 'generateContent' in m.supported_generation_methods:
        print(f"  - {m.name}")

print("\nTesting gemini-pro...")
try:
    model = genai.GenerativeModel('gemini-pro')
    response = model.generate_content("Say hello in 5 words")
    print(f"SUCCESS! Response: {response.text}")
except Exception as e:
    print(f"ERROR: {e}")
