import torch
from transformers import AutoTokenizer, AutoModelForCausalLM
from peft import PeftModel

BASE_MODEL = "TinyLlama/TinyLlama-1.1B-Chat-v1.0"
LORA_PATH = "models/izypt_lora_adapter/izypt_lora_adapter"

def load_llm():
    tokenizer = AutoTokenizer.from_pretrained(BASE_MODEL)

    device = "cuda" if torch.cuda.is_available() else "cpu"
    
    model = AutoModelForCausalLM.from_pretrained(
        BASE_MODEL,
        torch_dtype=torch.float16 if torch.cuda.is_available() else torch.float32,
        low_cpu_mem_usage=True
    ).to(device)

    model = PeftModel.from_pretrained(model, LORA_PATH)
    model.eval()

    return model, tokenizer
