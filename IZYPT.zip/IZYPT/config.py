"""
Configuration settings for IZYPT Chatbot & Sales/Support Agent
"""
import os

# LLM Configuration - Using Gemini API
USE_GEMINI_API = True  # Set to False to use local TinyLlama model
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "AIzaSyB4JsYelP_Q2h8WkGeYzZeVMO2curIPf8U")
GEMINI_MODEL = "gemini-3-pro-preview"  # or "gemini-1.5-pro" for even better quality

# Database Configuration
DB_PATH = os.path.join(os.path.dirname(__file__), "IZYPT_DB", "orders_database.db")

# LLM Model Configuration
BASE_MODEL = "TinyLlama/TinyLlama-1.1B-Chat-v1.0"
LORA_ADAPTER_PATH = os.path.join(os.path.dirname(__file__), "models", "izypt_lora_adapter", "izypt_lora_adapter")

# Generation Parameters
CHAT_MAX_TOKENS = 80  # For text chat
VOICE_MAX_TOKENS = 30  # For Twilio voice (faster responses)
TEMPERATURE = 0.7

# Conversation Management
MAX_HISTORY_MESSAGES = 10  # Maximum messages to keep in conversation history
MAX_CONTEXT_TOKENS = 1500  # Approximate token limit for context window

# System Prompts
SUPPORT_SYSTEM_PROMPT = """You are IZYPT's AI customer support assistant. You help customers with:
- Order status and tracking
- Delivery complaints and issues
- Order cancellations and modifications
- General customer service inquiries

Be polite, concise, and helpful. When you have order information, provide specific details.
If you need to look up an order, ask for the customer's phone number or order ID."""

SALES_SYSTEM_PROMPT = """You are IZYPT's AI sales assistant. You help customers with:
- Product recommendations
- Placing new orders
- Special offers and promotions
- Menu and availability questions

Be friendly, persuasive, and helpful. Guide customers to complete their orders."""

VOICE_SYSTEM_PROMPT = """You are IZYPT's helpful phone support agent. 

When database information is provided, use it to answer the customer's question directly and concisely.

Keep responses SHORT (under 20 words) and FACTUAL. Do not ask unnecessary questions. Do not make up information.

If no database info is found, politely ask for their phone number or order ID."""

# Twilio Configuration
TWILIO_ACCOUNT_SID = os.getenv("TWILIO_ACCOUNT_SID", "AC0d754c3a13ce3bc41f5877c84c7c63b6")
TWILIO_AUTH_TOKEN = os.getenv("TWILIO_AUTH_TOKEN", "fd2e685a983e5155603c7caab9b65154")
TWILIO_PHONE_NUMBER = os.getenv("TWILIO_PHONE_NUMBER", "+14845597215")

# Session Configuration
SESSION_TIMEOUT_MINUTES = 30  # Auto-cleanup inactive sessions
