"""
Gemini API Integration for IZYPT Chatbot
Uses Google's Gemini API instead of local LLM
"""
import google.generativeai as genai
import config


class GeminiAgent:
    """Agent using Google Gemini API"""
    
    def __init__(self):
        """Initialize Gemini API"""
        genai.configure(api_key=config.GEMINI_API_KEY)
        
        # Use available model - gemini-2.5-flash (fast and current)
        model_name = "gemini-2.5-flash"
        
        self.model = genai.GenerativeModel(model_name)
        print(f"[Gemini] Initialized with model: {model_name}")
    
    def generate(self, prompt: str, max_tokens: int = 100) -> str:
        """
        Generate response using Gemini API
        
        Args:
            prompt: Full prompt including system instruction and history
            max_tokens: Maximum tokens to generate
        
        Returns:
            Generated response text
        """
        try:
            # Generate response with simple config
            response = self.model.generate_content(prompt)
            
            # Check if response has text
            if hasattr(response, 'text') and response.text:
                return response.text.strip()
            elif hasattr(response, 'parts') and len(response.parts) > 0:
                return response.parts[0].text.strip()
            else:
                # Handle blocked/empty responses
                print(f"[Gemini] Response blocked or empty")
                return "I can help you with your order. Please provide your phone number or order ID."
            
        except Exception as e:
            print(f"[Gemini] Error: {e}")
            return "I'm here to help. Could you please rephrase your question?"


# Global instance
_gemini_agent = None

def get_gemini_agent() -> GeminiAgent:
    """Get global Gemini agent instance"""
    global _gemini_agent
    if _gemini_agent is None:
        _gemini_agent = GeminiAgent()
    return _gemini_agent
