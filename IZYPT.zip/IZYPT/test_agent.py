"""
Test script for IZYPT Chatbot Agent
Tests multi-turn conversation and database integration
"""
from agent import get_agent
from conversation_manager import conversation_manager
import time


def print_separator():
    print("\n" + "="*70 + "\n")


def test_order_lookup():
    """Test order lookup functionality"""
    print_separator()
    print("[TEST 1] Order Lookup by Phone Number")
    print_separator()
    
    agent = get_agent()
    
    # Create a new session
    session_id = conversation_manager.create_session(mode="support")
    print(f"Session created: {session_id}\n")
    
    # Test 1: Ask about order with phone number
    message1 = "Can you check my order status? My phone number is 620179012"
    print(f"User: {message1}")
    
    start = time.time()
    _, response1, db_info1 = agent.chat(message1, session_id)
    elapsed = time.time() - start
    
    print(f"Agent: {response1}")
    print(f"\n[Time: {elapsed:.2f}s]")
    if db_info1:
        print(f"[Database: {db_info1['info'][:100]}...]")
    
    print_separator()
    
    # Test 2: Follow-up question
    message2 = "Can you tell me more about why it was cancelled?"
    print(f"User: {message2}")
    
    start = time.time()
    _, response2, _ = agent.chat(message2, session_id)
    elapsed = time.time() - start
    
    print(f"Agent: {response2}")
    print(f"\n[Time: {elapsed:.2f}s]")
    
    return session_id


def test_multi_turn_conversation(session_id):
    """Test multi-turn conversation"""
    print_separator()
    print("[TEST 2] Multi-turn Conversation")
    print_separator()
    
    agent = get_agent()
    
    # Continue with same session
    message3 = "I want to place a new order. What do you recommend?"
    print(f"User: {message3}")
    
    start = time.time()
    _, response3, _ = agent.chat(message3, session_id)
    elapsed = time.time() - start
    
    print(f"Agent: {response3}")
    print(f"\n[Time: {elapsed:.2f}s]")
    
    print_separator()


def test_voice_mode():
    """Test voice mode with short responses"""
    print_separator()
    print("[TEST 3] Voice Mode (Short Responses)")
    print_separator()
    
    agent = get_agent()
    
    # Create voice session
    session_id = conversation_manager.create_session(mode="voice")
    print(f"Voice session created: {session_id}\n")
    
    message = "Check order for phone 7542014842"
    print(f"User: {message}")
    
    start = time.time()
    _, response, db_info = agent.chat(message, session_id, mode="voice")
    elapsed = time.time() - start
    
    print(f"Agent: {response}")
    print(f"\n[Time: {elapsed:.2f}s] (Voice mode - shorter response)")
    if db_info:
        print(f"[Database query performed]")
    
    print_separator()


def test_conversation_history(session_id):
    """View conversation history"""
    print_separator()
    print("[TEST 4] Conversation History")
    print_separator()
    
    history = conversation_manager.get_history(session_id)
    info = conversation_manager.get_session_info(session_id)
    
    print(f"Session: {info['session_id']}")
    print(f"Mode: {info['mode']}")
    print(f"Messages: {info['message_count']}")
    print(f"\nHistory:")
    
    for i, msg in enumerate(history, 1):
        role = msg['role'].capitalize()
        content = msg['content'][:100] + "..." if len(msg['content']) > 100 else msg['content']
        print(f"  {i}. {role}: {content}")
    
    print_separator()


if __name__ == "__main__":
    print("\n" + "="*70)
    print(" "*20 + "IZYPT CHATBOT TEST SUITE")
    print("="*70)
    
    try:
        # Run tests
        session_id = test_order_lookup()
        test_multi_turn_conversation(session_id)
        test_voice_mode()
        test_conversation_history(session_id)
        
        print("\n[SUCCESS] All tests completed!")
        print("\nTo start the API server, run:")
        print("  python api.py")
        print("  or")
        print("  uvicorn api:app --reload")
        
    except Exception as e:
        print(f"\n[ERROR] Test failed: {e}")
        import traceback
        traceback.print_exc()
