from database_tools import search_orders_by_phone
from agent import IZYPTAgent

# Test 1: Direct database search
print("=== Test 1: Direct Database Search ===")
orders = search_orders_by_phone('620179012')
print(f"Found {len(orders)} orders for 620179012")
if orders:
    print(f"Order ID: {orders[0]['order_id']}")
    print(f"Phone: {orders[0]['phone']}")
    print(f"Status: {orders[0]['status']}")

# Test 2: With spaces (like Twilio transcription)
print("\n=== Test 2: With Spaces ===")
orders2 = search_orders_by_phone('620 179012')
print(f"Found {len(orders2)} orders for '620 179012'")

# Test 3: Agent extraction
print("\n=== Test 3: Agent Extraction ===")
agent = IZYPTAgent()
params = agent._extract_search_params("Check my order for phone 620 179012")
print(f"Extracted params: {params}")

if 'phone' in params:
    orders3 = search_orders_by_phone(params['phone'])
    print(f"Found {len(orders3)} orders using extracted phone")
