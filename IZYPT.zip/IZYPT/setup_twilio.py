"""
Twilio Voice Agent Setup Helper
Checks prerequisites and guides through setup
"""
import subprocess
import sys

def check_ngrok():
    """Check if ngrok is installed"""
    try:
        result = subprocess.run(['ngrok', 'version'], capture_output=True, text=True)
        if result.returncode == 0:
            print("✓ ngrok is installed")
            print(f"  Version: {result.stdout.strip()}")
            return True
    except FileNotFoundError:
        pass
    
    print("✗ ngrok is NOT installed")
    return False

def print_setup_instructions():
    """Print setup instructions"""
    print("\n" + "="*70)
    print(" "*20 + "TWILIO VOICE AGENT SETUP")
    print("="*70)
    
    # Check ngrok
    ngrok_installed = check_ngrok()
    
    print("\n" + "-"*70)
    print("SETUP CHECKLIST:")
    print("-"*70)
    
    print("\n1. ✓ API Server: Running on http://localhost:8000")
    print("2. ✓ Twilio Credentials: Configured")
    print("3. ✓ Phone Number: +1 (484) 559-7215")
    
    if ngrok_installed:
        print("4. ✓ ngrok: Installed")
        print("\n" + "-"*70)
        print("NEXT STEPS:")
        print("-"*70)
        print("\n📍 Step 1: Start ngrok")
        print("   Open a NEW terminal and run:")
        print("   > ngrok http 8000")
        print("\n   This will give you a URL like: https://abc123.ngrok-free.app")
        print("   COPY THIS URL - you'll need it for Step 2")
    else:
        print("4. ✗ ngrok: Not installed")
        print("\n" + "-"*70)
        print("NEXT STEPS:")
        print("-"*70)
        print("\n📥 Step 1: Install ngrok")
        print("   Visit: https://ngrok.com/download")
        print("   Or run: choco install ngrok (if you have Chocolatey)")
        print("\n📍 Step 2: Start ngrok")
        print("   Open a NEW terminal and run:")
        print("   > ngrok http 8000")
    
    print("\n📞 Step 2: Configure Twilio Webhook")
    print("   1. Go to: https://console.twilio.com/us1/develop/phone-numbers/manage/incoming")
    print("   2. Click on phone number: (484) 559-7215")
    print("   3. Under 'Voice Configuration':")
    print("      - A CALL COMES IN: Webhook")
    print("      - URL: https://YOUR-NGROK-URL/twilio/voice")
    print("      - HTTP: POST")
    print("   4. Under 'Status Callback URL':")
    print("      - URL: https://YOUR-NGROK-URL/twilio/status")
    print("   5. Click SAVE")
    
    print("\n🎯 Step 3: Test the Voice Agent")
    print("   Call: (484) 559-7215")
    print("   Say: 'Check my order for phone 620179012'")
    print("   The agent will query the database and respond!")
    
    print("\n" + "="*70)
    print("\n💡 TIP: For detailed instructions, see TWILIO_SETUP.md")
    print("\n📚 Full documentation: http://localhost:8000/docs")
    print("\n" + "="*70)

if __name__ == "__main__":
    print_setup_instructions()
