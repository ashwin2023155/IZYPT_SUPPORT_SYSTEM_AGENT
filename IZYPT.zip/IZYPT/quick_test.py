"""
Quick test script to interact with the IZYPT Chatbot API
Test text chat without needing Twilio
"""
import requests
import json

API_URL = "http://localhost:8000"

def test_chat():
    print("=" * 70)
    print("IZYPT Chatbot - Quick Test")
    print("=" * 70)
    
    # Test 1: Simple order lookup
    print("\n[Test 1] Order Lookup")
    print("-" * 70)
    
    response1 = requests.post(f"{API_URL}/chat", json={
        "message": "Can you check my order? My phone is 620179012"
    })
    
    result1 = response1.json()
    session_id = result1["session_id"]
    
    print(f"User: Can you check my order? My phone is 620179012")
    print(f"Agent: {result1['response']}")
    print(f"\nSession ID: {session_id}")
    
    # Test 2: Follow-up question (multi-turn)
    print("\n[Test 2] Multi-turn Conversation")
    print("-" * 70)
    
    response2 = requests.post(f"{API_URL}/chat", json={
        "message": "When was it ordered?",
        "session_id": session_id
    })
    
    result2 = response2.json()
    
    print(f"User: When was it ordered?")
    print(f"Agent: {result2['response']}")
    
    # Show conversation history
    print("\n[Test 3] View History")
    print("-" * 70)
    
    history_response = requests.get(f"{API_URL}/chat/{session_id}/history")
    history = history_response.json()
    
    print(f"Session: {history['session_info']['session_id']}")
    print(f"Messages: {history['session_info']['message_count']}")
    print("\nConversation:")
    for i, msg in enumerate(history['history'], 1):
        print(f"  {i}. {msg['role'].capitalize()}: {msg['content'][:80]}...")
    
    print("\n" + "=" * 70)
    print("✓ All tests completed!")
    print("=" * 70)
    
    print("\n💡 TIP: You can now test the API from:")
    print("  - Postman")
    print("  - curl commands")
    print("  - Your own applications")
    print(f"\n📡 API Documentation: {API_URL}/docs")

if __name__ == "__main__":
    try:
        test_chat()
    except requests.exceptions.ConnectionError:
        print("❌ ERROR: Cannot connect to API server.")
        print("Make sure the server is running:")
        print("  uvicorn api:app --host 0.0.0.0 --port 8000")
    except Exception as e:
        print(f"❌ ERROR: {e}")
