"""
Database query tools for IZYPT chatbot
Provides functions to search orders and customer information
"""
import sqlite3
from typing import List, Dict, Optional
import config


def get_db_connection():
    """Create and return a database connection"""
    conn = sqlite3.connect(config.DB_PATH)
    conn.row_factory = sqlite3.Row  # Enable column access by name
    return conn


def search_order_by_id(order_id: str) -> Optional[Dict]:
    """
    Search for an order by order ID
    
    Args:
        order_id: Order ID (e.g., "#ORD-250629-733")
    
    Returns:
        Dictionary with order details or None if not found
    """
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute("""
        SELECT order_id, customer_name, phone, restaurant, order_date, 
               amount, items, status
        FROM orders
        WHERE order_id LIKE ?
    """, (f"%{order_id}%",))
    
    row = cursor.fetchone()
    conn.close()
    
    if row:
        return dict(row)
    return None


def search_orders_by_phone(phone: str) -> List[Dict]:
    """
    Search for orders by customer phone number
    
    Args:
        phone: Phone number (can be partial)
    
    Returns:
        List of order dictionaries
    """
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Clean phone number (remove spaces, dashes, etc.)
    clean_phone = ''.join(filter(str.isdigit, phone))
    
    cursor.execute("""
        SELECT order_id, customer_name, phone, restaurant, order_date, 
               amount, items, status
        FROM orders
        WHERE CAST(phone AS TEXT) LIKE ?
        ORDER BY order_date DESC
        LIMIT 10
    """, (f"%{clean_phone}%",))
    
    rows = cursor.fetchall()
    conn.close()
    
    return [dict(row) for row in rows]


def search_orders_by_name(name: str) -> List[Dict]:
    """
    Search for orders by customer name
    
    Args:
        name: Customer name (partial match supported)
    
    Returns:
        List of order dictionaries
    """
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute("""
        SELECT order_id, customer_name, phone, restaurant, order_date, 
               amount, items, status
        FROM orders
        WHERE customer_name LIKE ?
        ORDER BY order_date DESC
        LIMIT 10
    """, (f"%{name}%",))
    
    rows = cursor.fetchall()
    conn.close()
    
    return [dict(row) for row in rows]


def get_customer_info(phone: str) -> Optional[Dict]:
    """
    Get customer information by phone number
    
    Args:
        phone: Customer phone number
    
    Returns:
        Dictionary with customer details or None if not found
    """
    conn = get_db_connection()
    cursor = conn.cursor()
    
    clean_phone = ''.join(filter(str.isdigit, phone))
    
    cursor.execute("""
        SELECT customer_id, name, email, phone, status, 
               joined_date, total_orders, total_spent
        FROM customers
        WHERE phone LIKE ?
    """, (f"%{clean_phone}%",))
    
    row = cursor.fetchone()
    conn.close()
    
    if row:
        return dict(row)
    return None


def format_order_for_llm(order: Dict) -> str:
    """
    Format order information in a readable way for the LLM
    
    Args:
        order: Order dictionary
    
    Returns:
        Formatted string
    """
    return f"""Order ID: {order['order_id']}
Customer: {order['customer_name']}
Phone: {order['phone']}
Restaurant: {order['restaurant']}
Date: {order['order_date']}
Amount: Rs. {order['amount']}
Items: {order['items']}
Status: {order['status'].upper()}"""


def format_orders_summary(orders: List[Dict]) -> str:
    """
    Format multiple orders as a summary for the LLM
    
    Args:
        orders: List of order dictionaries
    
    Returns:
        Formatted summary string
    """
    if not orders:
        return "No orders found."
    
    if len(orders) == 1:
        return format_order_for_llm(orders[0])
    
    summary = f"Found {len(orders)} orders:\n\n"
    for i, order in enumerate(orders, 1):
        summary += f"{i}. Order {order['order_id']} - {order['order_date']} - Rs. {order['amount']} - {order['status'].upper()}\n"
    
    summary += f"\nMost recent order details:\n{format_order_for_llm(orders[0])}"
    return summary


def format_customer_for_llm(customer: Dict) -> str:
    """
    Format customer information for the LLM
    
    Args:
        customer: Customer dictionary
    
    Returns:
        Formatted string
    """
    return f"""Customer: {customer['name']}
Phone: {customer['phone']}
Email: {customer.get('email', 'N/A')}
Status: {customer['status']}
Member since: {customer['joined_date']}
Total orders: {customer['total_orders']}
Total spent: Rs. {customer['total_spent']}"""


# Tool descriptions for the LLM (for function calling)
TOOLS = [
    {
        "name": "search_order_by_id",
        "description": "Search for a specific order by order ID. Use when customer provides an order number.",
        "parameters": {
            "order_id": "The order ID to search for"
        }
    },
    {
        "name": "search_orders_by_phone",
        "description": "Search for all orders placed by a phone number. Use when customer provides their phone number.",
        "parameters": {
            "phone": "The customer's phone number"
        }
    },
    {
        "name": "search_orders_by_name",
        "description": "Search for orders by customer name. Use when customer provides their name.",
        "parameters": {
            "name": "The customer's name"
        }
    },
    {
        "name": "get_customer_info",
        "description": "Get customer profile information by phone number.",
        "parameters": {
            "phone": "The customer's phone number"
        }
    }
]
