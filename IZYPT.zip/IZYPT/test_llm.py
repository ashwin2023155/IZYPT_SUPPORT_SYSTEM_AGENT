from llm.loader import load_llm
import time

print("Loading model...")
start_time = time.time()
try:
    model, tokenizer = load_llm()
    load_time = time.time() - start_time
    print(f"[OK] LLM loaded successfully in {load_time:.2f}s")
except Exception as e:
    print(f"[ERROR] Failed to load model: {e}")
    exit(1)

# Test prompt
prompt = """### Instruction:
Handle a late grocery delivery complaint

### Input:
My groceries are delayed again.

### Response:
"""

print("\nGenerating response...")
inputs = tokenizer(prompt, return_tensors="pt").to(model.device)

try:
    gen_start = time.time()
    output = model.generate(
        **inputs,
        max_new_tokens=50,
        temperature=0.7,
        do_sample=True,
        pad_token_id=tokenizer.eos_token_id
    )
    gen_time = time.time() - gen_start
    print(f"[OK] Generated in {gen_time:.2f}s\n")
    
    print("--- MODEL OUTPUT ---")
    print(tokenizer.decode(output[0], skip_special_tokens=True))
    print("--- END OUTPUT ---")
    
except Exception as e:
    print(f"[ERROR] Generation failed: {e}")
    exit(1)

