# IZYPT Twilio Voice Agent Setup Guide

## ✅ Configuration Complete!

Your Twilio credentials are configured:
- **Account SID**: AC0d754c3a13ce3bc41f5877c84c7c63b6
- **Auth Token**: fd2e685a983e5155603c7caab9b65154  
- **Phone Number**: +1 (484) 559-7215

---

## 🚀 Setup Steps

### Step 1: Install ngrok (if not already installed)

Download ngrok from: https://ngrok.com/download

Or install via package manager:
```bash
# Windows (using Chocolatey)
choco install ngrok

# Or download and extract to a folder in your PATH
```

### Step 2: Start ngrok to expose your local server

Open a **NEW terminal** and run:
```bash
ngrok http 8000
```

You'll see output like:
```
Forwarding  https://abc123def456.ngrok-free.app -> http://localhost:8000
```

**Copy the HTTPS URL** (e.g., `https://abc123def456.ngrok-free.app`)

### Step 3: Configure Twilio Webhook

1. Go to: https://console.twilio.com/us1/develop/phone-numbers/manage/incoming
2. Click on your phone number: **(484) 559-7215**
3. Scroll to **Voice Configuration**:
   - **A CALL COMES IN**: Select "Webhook"
   - **URL**: `https://YOUR-NGROK-URL.ngrok-free.app/twilio/voice`
   - **HTTP**: POST
4. Scroll to **Status Callback URL**:
   - **URL**: `https://YOUR-NGROK-URL.ngrok-free.app/twilio/status`
   - **HTTP**: POST
5. Click **Save**

**Example:**
If your ngrok URL is `https://abc123.ngrok-free.app`, then set:
- Voice webhook: `https://abc123.ngrok-free.app/twilio/voice`
- Status callback: `https://abc123.ngrok-free.app/twilio/status`

---

## 📞 Test the Voice Agent

### Make a Test Call:

1. Call **(484) 559-7215**
2. You'll hear: "Hello! Welcome to IZYPT customer support..."
3. Say: **"Check my order status for phone number 620179012"**
4. The agent will:
   - Query the database
   - Find the order
   - Read back the order details
   - Ask if you need anything else

### Example Queries:
- "What's the status of my order?"
- "Check order for phone 7542014842"
- "I need help with my delivery"
- "Tell me about my recent orders"

---

## 🔧 Troubleshooting

### "I hear nothing when I call"
- Check that ngrok is running
- Verify the webhook URL in Twilio console
- Check API server logs for errors

### "The response is very slow"
- Expected on CPU (~10-15 seconds)
- For production, deploy to GPU server for <1s responses
- Temporary fix: Reduce `VOICE_MAX_TOKENS` in config.py to 20

### "Connection refused"
- Make sure the API server is running on port 8000
- Check that ngrok is forwarding to the correct port

### View Logs:
- **API Server**: Check the terminal running uvicorn
- **Twilio Logs**: console.twilio.com → Monitor → Logs → Calls

---

## 🎯 Current Status

✅ API Server: Running on http://localhost:8000  
✅ Twilio Credentials: Configured  
✅ Phone Number: +1 (484) 559-7215  
⏳ ngrok: **You need to start this**  
⏳ Webhook: **You need to configure in Twilio console**

---

## 📝 Quick Reference

**Your ngrok command:**
```bash
ngrok http 8000
```

**Your Twilio webhook URLs** (replace with your ngrok URL):
- Voice: `https://YOUR-NGROK-URL/twilio/voice`
- Status: `https://YOUR-NGROK-URL/twilio/status`

**Test the text chat (no Twilio needed):**
```bash
python quick_test.py
```

**View API docs:**
http://localhost:8000/docs
