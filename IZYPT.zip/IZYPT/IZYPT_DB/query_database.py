import sqlite3
from pathlib import Path
from typing import List, Dict, Any

class OrdersDatabase:
    """Helper class to query the orders database"""
    
    def __init__(self, db_path=None):
        """Initialize database connection"""
        if db_path is None:
            db_path = Path(__file__).parent / 'orders_database.db'
        
        self.db_path = db_path
        self.conn = sqlite3.connect(db_path)
        self.conn.row_factory = sqlite3.Row  # Enable column access by name
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
    
    def close(self):
        """Close database connection"""
        if self.conn:
            self.conn.close()
    
    def execute_query(self, query: str, params: tuple = ()) -> List[Dict[str, Any]]:
        """Execute a query and return results as list of dictionaries"""
        cursor = self.conn.cursor()
        cursor.execute(query, params)
        return [dict(row) for row in cursor.fetchall()]
    
    # Customer queries
    
    def get_all_customers(self) -> List[Dict[str, Any]]:
        """Get all customers"""
        return self.execute_query('SELECT * FROM customers ORDER BY name')
    
    def get_customer_by_phone(self, phone: str) -> List[Dict[str, Any]]:
        """Get customer by phone number"""
        return self.execute_query(
            'SELECT * FROM customers WHERE phone LIKE ?',
            (f'%{phone}%',)
        )
    
    def get_customer_by_name(self, name: str) -> List[Dict[str, Any]]:
        """Get customer by name (partial match)"""
        return self.execute_query(
            'SELECT * FROM customers WHERE name LIKE ?',
            (f'%{name}%',)
        )
    
    def get_customer_by_id(self, customer_id: str) -> List[Dict[str, Any]]:
        """Get customer by ID"""
        return self.execute_query(
            'SELECT * FROM customers WHERE customer_id = ?',
            (customer_id,)
        )
    
    def count_customers(self) -> int:
        """Get total number of customers"""
        result = self.execute_query('SELECT COUNT(*) as count FROM customers')
        return result[0]['count'] if result else 0
    
    # Order queries
    
    def get_all_orders(self, limit: int = None) -> List[Dict[str, Any]]:
        """Get all orders"""
        query = 'SELECT * FROM orders ORDER BY order_date DESC'
        if limit:
            query += f' LIMIT {limit}'
        return self.execute_query(query)
    
    def get_order_by_id(self, order_id: str) -> List[Dict[str, Any]]:
        """Get order by order ID"""
        return self.execute_query(
            'SELECT * FROM orders WHERE order_id = ?',
            (order_id,)
        )
    
    def get_orders_by_customer(self, customer_name: str) -> List[Dict[str, Any]]:
        """Get all orders for a customer (partial name match)"""
        return self.execute_query(
            'SELECT * FROM orders WHERE customer_name LIKE ? ORDER BY order_date DESC',
            (f'%{customer_name}%',)
        )
    
    def get_orders_by_phone(self, phone: str) -> List[Dict[str, Any]]:
        """Get all orders for a phone number"""
        return self.execute_query(
            'SELECT * FROM orders WHERE phone LIKE ? ORDER BY order_date DESC',
            (f'%{phone}%',)
        )
    
    def get_orders_by_status(self, status: str) -> List[Dict[str, Any]]:
        """Get orders by status (delivered/cancelled)"""
        return self.execute_query(
            'SELECT * FROM orders WHERE status = ? ORDER BY order_date DESC',
            (status,)
        )
    
    def get_delivered_orders(self) -> List[Dict[str, Any]]:
        """Get all delivered orders"""
        return self.get_orders_by_status('delivered')
    
    def get_cancelled_orders(self) -> List[Dict[str, Any]]:
        """Get all cancelled orders"""
        return self.get_orders_by_status('cancelled')
    
    def count_orders(self) -> Dict[str, int]:
        """Get order counts by status"""
        results = self.execute_query(
            'SELECT status, COUNT(*) as count FROM orders GROUP BY status'
        )
        counts = {row['status']: row['count'] for row in results}
        counts['total'] = sum(counts.values())
        return counts
    
    def search_orders(self, search_term: str) -> List[Dict[str, Any]]:
        """Search orders by customer name, order ID, or phone"""
        return self.execute_query('''
            SELECT * FROM orders 
            WHERE customer_name LIKE ? 
               OR order_id LIKE ? 
               OR phone LIKE ?
            ORDER BY order_date DESC
        ''', (f'%{search_term}%', f'%{search_term}%', f'%{search_term}%'))
    
    # Statistics queries
    
    def get_order_statistics(self) -> Dict[str, Any]:
        """Get overall order statistics"""
        stats = {}
        
        # Total orders
        counts = self.count_orders()
        stats['total_orders'] = counts['total']
        stats['delivered_orders'] = counts.get('delivered', 0)
        stats['cancelled_orders'] = counts.get('cancelled', 0)
        
        # Total customers
        stats['total_customers'] = self.count_customers()
        
        return stats

# Demo usage
def demo():
    """Demonstration of how to use the database"""
    
    print("=" * 60)
    print("Orders Database Query Demo")
    print("=" * 60)
    
    with OrdersDatabase() as db:
        # Get statistics
        print("\n📊 Database Statistics:")
        stats = db.get_order_statistics()
        print(f"   Total Customers: {stats['total_customers']}")
        print(f"   Total Orders: {stats['total_orders']}")
        print(f"   Delivered: {stats['delivered_orders']}")
        print(f"   Cancelled: {stats['cancelled_orders']}")
        
        # Search for a customer
        print("\n👤 Sample Customer Search (searching for 'Dev'):")
        customers = db.get_customer_by_name('Dev')
        for i, customer in enumerate(customers[:3]):  # Show first 3
            print(f"   {i+1}. {customer['name']} - {customer['phone']} - {customer['status']}")
        
        # Get orders for a customer
        print("\n📦 Sample Orders Search (searching for 'Dev'):")
        orders = db.get_orders_by_customer('Dev')
        for i, order in enumerate(orders[:5]):  # Show first 5
            print(f"   {i+1}. {order['order_id']} - ₹{order['amount']} - {order['status']}")
        
        # Get cancelled orders
        print("\n❌ Recent Cancelled Orders:")
        cancelled = db.get_cancelled_orders()
        for i, order in enumerate(cancelled[:5]):  # Show first 5
            print(f"   {i+1}. {order['order_id']} - {order['customer_name']} - ₹{order['amount']}")
        
        # Custom query example
        print("\n🔍 Custom Query Example - Orders with 'Spicy':")
        custom_results = db.execute_query(
            "SELECT order_id, customer_name, items, status FROM orders WHERE items LIKE ? LIMIT 5",
            ('%Spicy%',)
        )
        for i, result in enumerate(custom_results):
            print(f"   {i+1}. {result['order_id']} - {result['customer_name']} - {result['items']}")
    
    print("\n" + "=" * 60)
    print("✓ Demo complete!")
    print("=" * 60)

if __name__ == "__main__":
    demo()
