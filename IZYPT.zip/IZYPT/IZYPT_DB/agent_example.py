"""
Example agent script that demonstrates how to answer user queries
using the orders database.

This can be integrated into any chatbot or agent system.
"""

from query_database import OrdersDatabase

def answer_query(user_question: str) -> str:
    """
    Answer user questions about orders and customers using the database.
    
    This is a simple example - in a real agent, you would use NLP or LLMs
    to better understand the user's intent.
    """
    
    user_question = user_question.lower()
    
    with OrdersDatabase() as db:
        
        # Question about statistics
        if 'how many' in user_question and 'customer' in user_question:
            count = db.count_customers()
            return f"There are {count} total customers in the database."
        
        if 'how many' in user_question and 'order' in user_question:
            counts = db.count_orders()
            return (f"There are {counts['total']} total orders: "
                   f"{counts.get('delivered', 0)} delivered and "
                   f"{counts.get('cancelled', 0)} cancelled.")
        
        # Questions about cancelled orders
        if 'cancelled' in user_question:
            cancelled = db.get_cancelled_orders()
            if 'how many' in user_question:
                return f"There are {len(cancelled)} cancelled orders."
            else:
                # Show recent cancelled orders
                recent = cancelled[:5]
                response = "Recent cancelled orders:\n"
                for order in recent:
                    response += f"- {order['order_id']}: {order['customer_name']} - ₹{order['amount']}\n"
                return response
        
        # Questions about delivered orders
        if 'delivered' in user_question:
            delivered = db.get_delivered_orders()
            if 'how many' in user_question:
                return f"There are {len(delivered)} delivered orders."
            else:
                # Show recent delivered orders
                recent = delivered[:5]
                response = "Recent delivered orders:\n"
                for order in recent:
                    response += f"- {order['order_id']}: {order['customer_name']} - ₹{order['amount']}\n"
                return response
        
        # Search for specific customer or order
        # Try to extract a search term (simple approach - would be better with NLP)
        search_keywords = ['orders for', 'customer', 'find', 'search', 'show me']
        for keyword in search_keywords:
            if keyword in user_question:
                # Extract the term after the keyword
                parts = user_question.split(keyword)
                if len(parts) > 1:
                    search_term = parts[1].strip().split()[0] if parts[1].strip() else None
                    if search_term:
                        # Try searching
                        orders = db.get_orders_by_customer(search_term)
                        if orders:
                            response = f"Found {len(orders)} orders for '{search_term}':\n"
                            for order in orders[:5]:
                                response += f"- {order['order_id']}: ₹{order['amount']} - {order['status']}\n"
                            return response
                        else:
                            return f"No orders found for '{search_term}'."
        
        # Default response
        return "I can help you with questions about customers and orders. Try asking:\n" \
               "- How many customers are there?\n" \
               "- How many orders are cancelled?\n" \
               "- Show me orders for Dev\n" \
               "- What are the recent delivered orders?"


def main():
    """Demo of the agent answering questions"""
    
    print("=" * 60)
    print("Agent Query Demo")
    print("=" * 60)
    
    # Example questions
    questions = [
        "How many customers are there?",
        "How many orders are cancelled?",
        "Show me orders for Dev",
        "What are the recent delivered orders?",
    ]
    
    for question in questions:
        print(f"\n❓ Question: {question}")
        answer = answer_query(question)
        print(f"💬 Answer: {answer}")
    
    print("\n" + "=" * 60)
    
    # Interactive mode
    print("\nEnter 'quit' to exit")
    while True:
        user_input = input("\n❓ Ask a question: ").strip()
        if user_input.lower() in ['quit', 'exit', 'q']:
            break
        
        if user_input:
            answer = answer_query(user_input)
            print(f"💬 Answer: {answer}")


if __name__ == "__main__":
    main()
