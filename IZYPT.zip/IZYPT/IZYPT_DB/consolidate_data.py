import pandas as pd
import os
import glob
from pathlib import Path

# Get the script directory
script_dir = Path(__file__).parent

def clean_phone(phone):
    """Clean phone number"""
    if pd.isna(phone) or phone == '-':
        return ''
    # Remove spaces and newlines
    return str(phone).replace(' ', '').replace('\r', '').replace('\n', '')

def clean_text(text):
    """Clean text fields by removing carriage returns and extra spaces"""
    if pd.isna(text) or text == '-':
        return ''
    return str(text).replace('\r', ' ').replace('\n', ' ').strip()

def consolidate_customers():
    """Consolidate all customer data into a single CSV"""
    print("Processing customer files...")
    
    # Find all customer CSV files
    customer_files = sorted(glob.glob(str(script_dir / 'customers_report_table_*.csv')))
    
    all_customers = []
    
    for file in customer_files:
        try:
            df = pd.read_csv(file, skiprows=1)  # Skip the first row with column indices
            
            # Skip if empty or invalid
            if df.empty or len(df.columns) < 8:
                continue
            
            # Rename columns to standard names
            df.columns = ['name', 'email', 'phone', 'customer_id', 'status', 'joined', 'total_orders', 'total_spent']
            
            # Clean the data
            df['name'] = df['name'].apply(clean_text)
            df['email'] = df['email'].apply(clean_text)
            df['phone'] = df['phone'].apply(clean_phone)
            df['customer_id'] = df['customer_id'].apply(clean_text)
            df['status'] = df['status'].apply(clean_text)
            df['joined'] = df['joined'].apply(clean_text)
            df['total_orders'] = df['total_orders'].apply(clean_text)
            df['total_spent'] = df['total_spent'].apply(clean_text)
            
            # Remove empty rows
            df = df[df['name'].str.len() > 0]
            
            all_customers.append(df)
            
        except Exception as e:
            print(f"Error processing {file}: {e}")
            continue
    
    # Combine all customer data
    if all_customers:
        customers_df = pd.concat(all_customers, ignore_index=True)
        
        # Remove duplicates based on customer_id
        customers_df = customers_df.drop_duplicates(subset=['customer_id'], keep='first')
        
        # Sort by joined date
        customers_df = customers_df.sort_values('joined', ascending=False)
        
        # Save to CSV
        output_file = script_dir / 'customers_master.csv'
        customers_df.to_csv(output_file, index=False)
        print(f"✓ Created {output_file} with {len(customers_df)} unique customers")
        
        return customers_df
    else:
        print("No customer data found")
        return None

def consolidate_orders():
    """Consolidate all delivered and cancelled order data into a single CSV"""
    print("\nProcessing order files...")
    
    # Find all order CSV files
    delivered_files = sorted(glob.glob(str(script_dir / 'delivered_orders_report_table_*.csv')))
    cancelled_files = sorted(glob.glob(str(script_dir / 'cancelled_orders_report_table_*.csv')))
    all_orders_files = sorted(glob.glob(str(script_dir / 'all_orders_report_table_*.csv')))
    
    all_orders = []
    
    # Process all order files (delivered, cancelled, and all_orders)
    all_files = delivered_files + cancelled_files + all_orders_files
    
    for file in all_files:
        try:
            df = pd.read_csv(file, skiprows=1)  # Skip the first row with column indices
            
            # Skip if empty or invalid
            if df.empty or len(df.columns) < 8:
                continue
            
            # Rename columns to standard names
            # Expected columns: S.No., Order ID, Customer, Phone, Restaurant, Date, Amount, Items, Status
            if len(df.columns) >= 9:
                df.columns = ['sno', 'order_id', 'customer', 'phone', 'restaurant', 'date', 'amount', 'items', 'status']
            else:
                # Some files might have 8 columns
                df.columns = ['sno', 'order_id', 'customer', 'phone', 'restaurant', 'date', 'amount', 'status']
                df['items'] = ''
            
            # Clean the data
            df['order_id'] = df['order_id'].apply(clean_text)
            df['customer'] = df['customer'].apply(clean_text)
            df['phone'] = df['phone'].apply(clean_phone)
            df['restaurant'] = df['restaurant'].apply(clean_text)
            df['date'] = df['date'].apply(clean_text)
            df['amount'] = df['amount'].apply(clean_text)
            df['items'] = df['items'].apply(clean_text) if 'items' in df.columns else ''
            df['status'] = df['status'].apply(clean_text)
            
            # Filter only delivered and cancelled orders
            df = df[df['status'].isin(['delivered', 'cancelled'])]
            
            # Remove empty rows (rows without order_id)
            df = df[df['order_id'].str.len() > 0]
            
            # Keep only the columns we need
            df = df[['order_id', 'customer', 'phone', 'restaurant', 'date', 'amount', 'items', 'status']]
            
            all_orders.append(df)
            
        except Exception as e:
            print(f"Error processing {file}: {e}")
            continue
    
    # Combine all order data
    if all_orders:
        orders_df = pd.concat(all_orders, ignore_index=True)
        
        # Remove duplicates based on order_id
        orders_df = orders_df.drop_duplicates(subset=['order_id'], keep='first')
        
        # Sort by date (most recent first)
        orders_df = orders_df.sort_values('date', ascending=False)
        
        # Save to CSV
        output_file = script_dir / 'orders_master.csv'
        orders_df.to_csv(output_file, index=False)
        print(f"✓ Created {output_file} with {len(orders_df)} orders")
        
        # Print statistics
        delivered_count = len(orders_df[orders_df['status'] == 'delivered'])
        cancelled_count = len(orders_df[orders_df['status'] == 'cancelled'])
        print(f"  - Delivered: {delivered_count}")
        print(f"  - Cancelled: {cancelled_count}")
        
        return orders_df
    else:
        print("No order data found")
        return None

def main():
    print("=" * 60)
    print("Consolidating CSV data into master tables")
    print("=" * 60)
    
    # Consolidate customers
    customers_df = consolidate_customers()
    
    # Consolidate orders
    orders_df = consolidate_orders()
    
    print("\n" + "=" * 60)
    print("✓ Data consolidation complete!")
    print("=" * 60)
    print("\nCreated files:")
    print("  1. customers_master.csv - All unique customers")
    print("  2. orders_master.csv - All delivered and cancelled orders")

if __name__ == "__main__":
    main()
