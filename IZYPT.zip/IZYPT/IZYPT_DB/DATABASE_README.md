# Orders Database System

This directory contains a complete database system for managing customer and order data.

## 📁 Files

### Database Files
- **`orders_database.db`** - SQLite database containing all customer and order data
- **`customers_master.csv`** - Master CSV file with 754 unique customers
- **`orders_master.csv`** - Master CSV file with 423 orders (370 delivered, 53 cancelled)

### Scripts
- **`create_database.py`** - Creates the database and populates it from CSV files
- **`query_database.py`** - Query helper class with common database operations
- **`consolidate_data.py`** - Consolidates raw CSV files into master files

## 📊 Database Schema

### Customers Table
```sql
CREATE TABLE customers (
    customer_id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT,
    phone TEXT,
    status TEXT,
    joined_date TEXT,
    total_orders TEXT,
    total_spent TEXT
)
```

### Orders Table
```sql
CREATE TABLE orders (
    order_id TEXT PRIMARY KEY,
    customer_name TEXT,
    phone TEXT,
    restaurant TEXT,
    order_date TEXT,
    amount TEXT,
    items TEXT,
    status TEXT CHECK(status IN ('delivered', 'cancelled'))
)
```

## 🚀 Usage

### Using the Query Helper Class

```python
from query_database import OrdersDatabase

# Initialize database connection
with OrdersDatabase() as db:
    # Get all customers
    customers = db.get_all_customers()
    
    # Search customer by phone
    customer = db.get_customer_by_phone('9905549099')
    
    # Get orders for a customer
    orders = db.get_orders_by_customer('Dev')
    
    # Get all cancelled orders
    cancelled = db.get_cancelled_orders()
    
    # Get statistics
    stats = db.get_order_statistics()
    print(f"Total Orders: {stats['total_orders']}")
```

### Available Query Methods

#### Customer Queries
- `get_all_customers()` - Get all customers
- `get_customer_by_phone(phone)` - Search by phone number
- `get_customer_by_name(name)` - Search by name (partial match)
- `get_customer_by_id(customer_id)` - Get by customer ID
- `count_customers()` - Get total customer count

#### Order Queries
- `get_all_orders(limit)` - Get all orders
- `get_order_by_id(order_id)` - Get specific order
- `get_orders_by_customer(name)` - Get orders for a customer
- `get_orders_by_phone(phone)` - Get orders by phone
- `get_orders_by_status(status)` - Get orders by status
- `get_delivered_orders()` - Get all delivered orders
- `get_cancelled_orders()` - Get all cancelled orders
- `search_orders(term)` - Search across customer name, order ID, and phone

#### Statistics
- `get_order_statistics()` - Get overall statistics
- `count_orders()` - Get counts by status

### Direct SQL Queries

```python
from query_database import OrdersDatabase

with OrdersDatabase() as db:
    # Execute custom SQL query
    results = db.execute_query(
        "SELECT * FROM orders WHERE amount > ? AND status = ?",
        ('1000', 'delivered')
    )
    
    for result in results:
        print(result['order_id'], result['customer_name'])
```

### Using SQLite Command Line

```bash
# Open database
sqlite3 orders_database.db

# Run queries
SELECT COUNT(*) FROM customers;
SELECT * FROM orders WHERE status = 'delivered' LIMIT 10;
SELECT customer_name, COUNT(*) as order_count 
FROM orders 
GROUP BY customer_name 
ORDER BY order_count DESC 
LIMIT 10;
```

## 📈 Database Statistics

- **Total Customers**: 754
- **Total Orders**: 423
  - Delivered: 370
  - Cancelled: 53

## 🔄 Rebuilding the Database

To recreate the database from CSV files:

```bash
python create_database.py
```

This will:
1. Delete the existing database (if any)
2. Create new tables with proper schema
3. Load all customer data from `customers_master.csv`
4. Load all order data from `orders_master.csv`
5. Create indexes for faster queries

## 🤖 For AI Agents

This database is designed to be easily queried by AI agents. Use the `OrdersDatabase` class from `query_database.py`:

```python
from query_database import OrdersDatabase

def answer_user_query(user_question):
    with OrdersDatabase() as db:
        # Example: User asks "How many orders did Dev place?"
        orders = db.get_orders_by_customer('Dev')
        return f"Dev has {len(orders)} orders"
```

## 📝 Notes

- All phone numbers are stored as strings to preserve leading zeros
- Dates are stored as text in the format they appear in the source data
- The database uses SQLite, which is serverless and doesn't require installation
- All queries return results as dictionaries for easy access to fields
