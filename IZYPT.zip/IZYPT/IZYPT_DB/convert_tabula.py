import tabula
import os

# Define PDF files to convert
pdf_files = [
    "all_orders_report .pdf",
    "cancelled_orders_report .pdf",
    "customers_report.pdf",
    "delivered_orders_report .pdf"
]

# Get the directory where this script is located
script_dir = os.path.dirname(os.path.abspath(__file__))

print("=" * 60)
print("PDF to CSV Converter (using tabula-py)")
print("=" * 60)

# Process each PDF file
for pdf_file in pdf_files:
    pdf_path = os.path.join(script_dir, pdf_file)
    
    # Check if file exists
    if not os.path.exists(pdf_path):
        print(f"\n❌ File not found: {pdf_file}")
        continue
    
    print(f"\n📄 Processing: {pdf_file}")
    print("-" * 60)
    
    try:
        # Read PDF tables using tabula
        # This will detect all tables across all pages
        tables = tabula.read_pdf(
            pdf_path,
            pages="all",
            multiple_tables=True,
            pandas_options={'header': None}  # Let pandas auto-detect headers
        )
        
        print(f"   ✓ Total tables found: {len(tables)}")
        
        # Export each table to CSV
        if len(tables) > 0:
            # Create base filename (remove .pdf extension)
            base_name = os.path.splitext(pdf_file)[0].strip()
            
            if len(tables) == 1:
                # Single table - save with simple name
                csv_filename = f"{base_name}.csv"
                csv_path = os.path.join(script_dir, csv_filename)
                tables[0].to_csv(csv_path, index=False)
                print(f"   ✓ Saved: {csv_filename}")
                print(f"      Rows: {len(tables[0])}, Columns: {len(tables[0].columns)}")
            else:
                # Multiple tables - save with table numbers
                for i, table in enumerate(tables, 1):
                    csv_filename = f"{base_name}_table_{i}.csv"
                    csv_path = os.path.join(script_dir, csv_filename)
                    table.to_csv(csv_path, index=False)
                    print(f"   ✓ Saved: {csv_filename}")
                    print(f"      Rows: {len(table)}, Columns: {len(table.columns)}")
        else:
            print(f"   ⚠ No tables found in {pdf_file}")
            
    except Exception as e:
        print(f"   ❌ Error processing {pdf_file}: {str(e)}")
        import traceback
        traceback.print_exc()
        continue

print("\n" + "=" * 60)
print("✓ Conversion complete!")
print("=" * 60)
