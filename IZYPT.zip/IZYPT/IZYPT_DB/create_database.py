import sqlite3
import pandas as pd
from pathlib import Path

def create_database():
    """Create SQLite database and tables"""
    
    script_dir = Path(__file__).parent
    db_path = script_dir / 'orders_database.db'
    
    # Remove existing database if it exists
    if db_path.exists():
        db_path.unlink()
        print(f"Removed existing database: {db_path}")
    
    # Create database connection
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    print("Creating database schema...")
    
    # Create customers table
    cursor.execute('''
        CREATE TABLE customers (
            customer_id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            email TEXT,
            phone TEXT,
            status TEXT,
            joined_date TEXT,
            total_orders TEXT,
            total_spent TEXT
        )
    ''')
    
    # Create orders table
    cursor.execute('''
        CREATE TABLE orders (
            order_id TEXT PRIMARY KEY,
            customer_name TEXT,
            phone TEXT,
            restaurant TEXT,
            order_date TEXT,
            amount TEXT,
            items TEXT,
            status TEXT CHECK(status IN ('delivered', 'cancelled'))
        )
    ''')
    
    # Create indexes for faster queries
    cursor.execute('CREATE INDEX idx_customer_name ON customers(name)')
    cursor.execute('CREATE INDEX idx_customer_phone ON customers(phone)')
    cursor.execute('CREATE INDEX idx_order_status ON orders(status)')
    cursor.execute('CREATE INDEX idx_order_date ON orders(order_date)')
    cursor.execute('CREATE INDEX idx_order_customer ON orders(customer_name)')
    
    conn.commit()
    print("✓ Database schema created successfully")
    
    return conn, cursor

def load_customers(conn, cursor, csv_path):
    """Load customers from CSV into database"""
    
    print("\nLoading customer data...")
    
    # Read CSV
    df = pd.read_csv(csv_path)
    
    # Insert data
    for _, row in df.iterrows():
        cursor.execute('''
            INSERT OR REPLACE INTO customers 
            (customer_id, name, email, phone, status, joined_date, total_orders, total_spent)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            str(row['customer_id']),
            str(row['name']),
            str(row['email']) if pd.notna(row['email']) else '',
            str(row['phone']) if pd.notna(row['phone']) else '',
            str(row['status']) if pd.notna(row['status']) else '',
            str(row['joined']) if pd.notna(row['joined']) else '',
            str(row['total_orders']) if pd.notna(row['total_orders']) else '',
            str(row['total_spent']) if pd.notna(row['total_spent']) else ''
        ))
    
    conn.commit()
    
    # Get count
    cursor.execute('SELECT COUNT(*) FROM customers')
    count = cursor.fetchone()[0]
    
    print(f"✓ Loaded {count} customers into database")
    
    return count

def load_orders(conn, cursor, csv_path):
    """Load orders from CSV into database"""
    
    print("\nLoading order data...")
    
    # Read CSV
    df = pd.read_csv(csv_path)
    
    # Insert data
    for _, row in df.iterrows():
        cursor.execute('''
            INSERT OR REPLACE INTO orders 
            (order_id, customer_name, phone, restaurant, order_date, amount, items, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            str(row['order_id']),
            str(row['customer']) if pd.notna(row['customer']) else '',
            str(row['phone']) if pd.notna(row['phone']) else '',
            str(row['restaurant']) if pd.notna(row['restaurant']) else '',
            str(row['date']) if pd.notna(row['date']) else '',
            str(row['amount']) if pd.notna(row['amount']) else '',
            str(row['items']) if pd.notna(row['items']) else '',
            str(row['status']) if pd.notna(row['status']) else ''
        ))
    
    conn.commit()
    
    # Get counts by status
    cursor.execute('SELECT status, COUNT(*) FROM orders GROUP BY status')
    status_counts = cursor.fetchall()
    
    cursor.execute('SELECT COUNT(*) FROM orders')
    total_count = cursor.fetchone()[0]
    
    print(f"✓ Loaded {total_count} orders into database")
    for status, count in status_counts:
        print(f"  - {status}: {count}")
    
    return total_count

def print_sample_queries(conn):
    """Print some sample queries to demonstrate database usage"""
    
    print("\n" + "=" * 60)
    print("Sample Database Queries")
    print("=" * 60)
    
    cursor = conn.cursor()
    
    # Sample query 1: Count customers
    print("\n1. Total customers:")
    cursor.execute('SELECT COUNT(*) FROM customers')
    print(f"   {cursor.fetchone()[0]} customers")
    
    # Sample query 2: Orders by status
    print("\n2. Orders by status:")
    cursor.execute('SELECT status, COUNT(*) FROM orders GROUP BY status')
    for status, count in cursor.fetchall():
        print(f"   {status}: {count}")
    
    # Sample query 3: Recent orders
    print("\n3. Most recent 5 orders:")
    cursor.execute('''
        SELECT order_id, customer_name, amount, status 
        FROM orders 
        LIMIT 5
    ''')
    for order_id, customer, amount, status in cursor.fetchall():
        print(f"   {order_id} - {customer} - ₹{amount} - {status}")
    
    # Sample query 4: Customers by phone
    print("\n4. Sample customer lookup by phone:")
    cursor.execute('''
        SELECT name, phone, status, joined_date 
        FROM customers 
        WHERE phone != '' 
        LIMIT 3
    ''')
    for name, phone, status, joined in cursor.fetchall():
        print(f"   {name} - {phone} - {status} - {joined}")

def main():
    """Main function to create and populate database"""
    
    print("=" * 60)
    print("Creating Orders Database")
    print("=" * 60)
    
    script_dir = Path(__file__).parent
    
    # Create database and schema
    conn, cursor = create_database()
    
    try:
        # Load customers
        customers_csv = script_dir / 'customers_master.csv'
        customer_count = load_customers(conn, cursor, customers_csv)
        
        # Load orders
        orders_csv = script_dir / 'orders_master.csv'
        order_count = load_orders(conn, cursor, orders_csv)
        
        # Print sample queries
        print_sample_queries(conn)
        
        print("\n" + "=" * 60)
        print("✓ Database created successfully!")
        print("=" * 60)
        print(f"\nDatabase location: {script_dir / 'orders_database.db'}")
        print(f"Total customers: {customer_count}")
        print(f"Total orders: {order_count}")
        print("\nYou can now query this database using SQL!")
        
    finally:
        conn.close()

if __name__ == "__main__":
    main()
