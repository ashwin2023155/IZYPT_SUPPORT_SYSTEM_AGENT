"""
FastAPI application for IZYPT Chatbot
Provides REST API endpoints for chat and Twilio webhook integration
"""
from fastapi import FastAPI, Request, Form, HTTPException
from fastapi.responses import Response, JSONResponse
from pydantic import BaseModel
from typing import Optional
import uvicorn

from agent import get_agent
from conversation_manager import conversation_manager
import twilio_handler


# Initialize FastAPI app
app = FastAPI(
    title="IZYPT Chatbot API",
    description="Customer support and sales chatbot for IZYPT food delivery",
    version="1.0.0"
)


# Pydantic models for request/response validation
class ChatRequest(BaseModel):
    message: str
    session_id: Optional[str] = None
    mode: Optional[str] = "support"  # support, sales, or voice


class ChatResponse(BaseModel):
    session_id: str
    response: str
    database_info: Optional[dict] = None


class SessionInfo(BaseModel):
    session_id: str
    mode: str
    message_count: int
    created_at: str
    last_activity: str


# Initialize agent on startup
@app.on_event("startup")
async def startup_event():
    """Load the LLM model when server starts"""
    print("[API] Starting IZYPT Chatbot API...")
    # Trigger agent initialization
    _ = get_agent()
    print("[API] Server ready!")


# ============================================================================
# Chat Endpoints
# ============================================================================

@app.post("/chat", response_model=ChatResponse)
async def chat(request: ChatRequest):
    """
    Send a message and get a response from the chatbot
    
    Args:
        request: ChatRequest with message, optional session_id, and mode
    
    Returns:
        ChatResponse with session_id, response, and optional database info
    """
    try:
        agent = get_agent()
        session_id, response, db_info = agent.chat(
            message=request.message,
            session_id=request.session_id,
            mode=request.mode
        )
        
        return ChatResponse(
            session_id=session_id,
            response=response,
            database_info=db_info
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error processing chat: {str(e)}")


@app.post("/chat/new")
async def new_chat_session(mode: str = "support"):
    """
    Create a new chat session
    
    Args:
        mode: Agent mode (support, sales, or voice)
    
    Returns:
        Session information
    """
    session_id = conversation_manager.create_session(mode=mode)
    return {"session_id": session_id, "mode": mode}


@app.get("/chat/{session_id}/history")
async def get_chat_history(session_id: str):
    """
    Get conversation history for a session
    
    Args:
        session_id: Session ID
    
    Returns:
        Conversation history
    """
    history = conversation_manager.get_history(session_id)
    if not history and session_id not in conversation_manager.sessions:
        raise HTTPException(status_code=404, detail="Session not found")
    
    info = conversation_manager.get_session_info(session_id)
    return {
        "session_info": info,
        "history": history
    }


@app.delete("/chat/{session_id}")
async def delete_chat_session(session_id: str):
    """
    Delete a chat session
    
    Args:
        session_id: Session ID to delete
    
    Returns:
        Success message
    """
    if session_id not in conversation_manager.sessions:
        raise HTTPException(status_code=404, detail="Session not found")
    
    conversation_manager.clear_session(session_id)
    return {"message": "Session deleted successfully"}


# ============================================================================
# Twilio Voice Webhooks
# ============================================================================

@app.post("/twilio/voice")
async def twilio_voice_webhook(request: Request):
    """
    Handle incoming Twilio voice call
    Returns TwiML to greet the caller and gather speech input
    """
    try:
        twiml = twilio_handler.create_welcome_twiml()
        return Response(content=twiml, media_type="application/xml")
    except Exception as e:
        print(f"[Twilio] Error in voice webhook: {e}")
        error_twiml = twilio_handler.create_error_twiml()
        return Response(content=error_twiml, media_type="application/xml")


@app.post("/twilio/gather")
async def twilio_gather_webhook(
    CallSid: str = Form(...),
    From: str = Form(...),
    SpeechResult: Optional[str] = Form(None)
):
    """
    Handle gathered speech from Twilio
    Processes user input and returns agent response as TwiML
    """
    try:
        # Check if we got speech input
        if not SpeechResult:
            twiml = twilio_handler.create_error_twiml("I didn't catch that. Could you please repeat?")
            return Response(content=twiml, media_type="application/xml")
        
        print(f"[Twilio] Call {CallSid} from {From}: {SpeechResult}")
        
        # Create session ID from call
        session_id = twilio_handler.get_session_id_from_call(CallSid, From)
        
        # Get agent and process message
        agent = get_agent()
        _, response, _ = agent.chat(
            message=SpeechResult,
            session_id=session_id,
            mode="voice"
        )
        
        # Optimize response for voice
        voice_response = twilio_handler.optimize_response_for_voice(response)
        
        print(f"[Twilio] Agent response: {voice_response}")
        
        # Create TwiML response
        twiml = twilio_handler.create_response_twiml(voice_response, continue_conversation=True)
        return Response(content=twiml, media_type="application/xml")
        
    except Exception as e:
        print(f"[Twilio] Error in gather webhook: {e}")
        error_twiml = twilio_handler.create_error_twiml()
        return Response(content=error_twiml, media_type="application/xml")


@app.post("/twilio/status")
async def twilio_status_callback(
    CallSid: str = Form(...),
    CallStatus: str = Form(...),
    From: str = Form(...)
):
    """
    Handle call status callbacks from Twilio
    Cleanup sessions when calls end
    """
    print(f"[Twilio] Call {CallSid} status: {CallStatus}")
    
    if CallStatus in ["completed", "busy", "no-answer", "failed", "canceled"]:
        # Clean up session
        session_id = twilio_handler.get_session_id_from_call(CallSid, From)
        if session_id in conversation_manager.sessions:
            conversation_manager.clear_session(session_id)
            print(f"[Twilio] Cleaned up session {session_id}")
    
    return {"status": "ok"}


# ============================================================================
# Health Check & Info Endpoints
# ============================================================================

@app.get("/")
async def root():
    """API information"""
    return {
        "name": "IZYPT Chatbot API",
        "version": "1.0.0",
        "endpoints": {
            "chat": "POST /chat",
            "new_session": "POST /chat/new",
            "history": "GET /chat/{session_id}/history",
            "delete_session": "DELETE /chat/{session_id}",
            "twilio_voice": "POST /twilio/voice",
            "twilio_gather": "POST /twilio/gather",
            "twilio_status": "POST /twilio/status"
        }
    }


@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "model_loaded": get_agent() is not None}


# ============================================================================
# Run the application
# ============================================================================

if __name__ == "__main__":
    uvicorn.run("api:app", host="0.0.0.0", port=8000, reload=True)
