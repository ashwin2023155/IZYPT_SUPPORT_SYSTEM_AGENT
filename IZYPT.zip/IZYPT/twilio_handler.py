"""
Twilio webhook handler for voice agent
Handles TwiML creation and voice-specific optimizations
"""
from twilio.twiml.voice_response import VoiceResponse, Gather
from typing import Dict
import config


def create_welcome_twiml() -> str:
    """
    Create TwiML for initial call greeting
    
    Returns:
        TwiML XML string
    """
    response = VoiceResponse()
    gather = Gather(
        input='speech',
        action='/twilio/gather',
        method='POST',
        speech_timeout='auto',
        language='en-IN'
    )
    
    gather.say(
        "Hello! Welcome to IZYPT customer support. "
        "How can I help you today? " 
        "You can ask about your order status, delivery, or any other questions.",
        voice='Polly.Aditi', 
        language='en-IN'
    )
    
    response.append(gather)
    response.say("I didn't hear anything. Goodbye!", voice='Polly.Aditi')
    response.hangup()
    
    return str(response)


def create_response_twiml(agent_response: str, continue_conversation: bool = True) -> str:
    """
    Create TwiML for agent response
    
    Args:
        agent_response: Text response from the agent
        continue_conversation: Whether to continue gathering input
    
    Returns:
        TwiML XML string
    """
    response = VoiceResponse()
    
    # Say the agent's response
    response.say(agent_response, voice='Polly.Aditi', language='en-IN')
    
    if continue_conversation:
        # Gather more input
        gather = Gather(
            input='speech',
            action='/twilio/gather',
            method='POST',
            speech_timeout='auto',
            language='en-IN'
        )
        
        gather.say(
            "Is there anything else I can help you with?",
            voice='Polly.Aditi',
            language='en-IN'
        )
        
        response.append(gather)
        response.say("Thank you for calling IZYPT. Goodbye!", voice='Polly.Aditi')
        response.hangup()
    else:
        response.say("Thank you for calling IZYPT. Goodbye!", voice='Polly.Aditi')
        response.hangup()
    
    return str(response)


def create_error_twiml(error_message: str = "Sorry, I encountered an error. Please try again.") -> str:
    """
    Create TwiML for error handling
    
    Args:
        error_message: Error message to say
    
    Returns:
        TwiML XML string
    """
    response = VoiceResponse()
    response.say(error_message, voice='Polly.Aditi', language='en-IN')
    
    gather = Gather(
        input='speech',
        action='/twilio/gather',
        method='POST',
        speech_timeout='auto',
        language='en-IN'
    )
    
    gather.say("Would you like to try again?", voice='Polly.Aditi', language='en-IN')
    response.append(gather)
    response.hangup()
    
    return str(response)


def get_session_id_from_call(call_sid: str, from_number: str) -> str:
    """
    Generate a session ID for a phone call
    Uses the caller's phone number to maintain session across the call
    
    Args:
        call_sid: Twilio call SID
        from_number: Caller's phone number
    
    Returns:
        Session ID
    """
    # Use phone number as session ID so we can track conversation
    # Remove any + or special characters
    clean_number = ''.join(filter(str.isdigit, from_number))
    return f"voice_{clean_number}_{call_sid[:8]}"


def optimize_response_for_voice(text: str) -> str:
    """
    Optimize text response for text-to-speech
    - Remove special characters that don't speak well
    - Simplify formatting
    
    Args:
        text: Original text response
    
    Returns:
        Voice-optimized text
    """
    # Remove markdown formatting
    text = text.replace("**", "").replace("*", "")
    text = text.replace("#", "")
    
    # Replace "Rs." with "rupees"
    text = text.replace("Rs.", "rupees").replace("Rs", "rupees")
    
    # Clean up extra whitespace
    text = " ".join(text.split())
    
    return text
