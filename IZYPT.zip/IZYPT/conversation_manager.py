"""
Conversation session manager for IZYPT chatbot
Handles multi-turn conversation history and session tracking
"""
import uuid
from typing import Dict, List, Optional
from datetime import datetime, timedelta
import config


class ConversationManager:
    """Manages conversation sessions and history"""
    
    def __init__(self):
        self.sessions: Dict[str, Dict] = {}
    
    def create_session(self, session_id: Optional[str] = None, mode: str = "support") -> str:
        """
        Create a new conversation session
        
        Args:
            session_id: Optional session ID (generated if not provided)
            mode: Agent mode - "support", "sales", or "voice"
        
        Returns:
            Session ID
        """
        if session_id is None:
            session_id = str(uuid.uuid4())
        
        # Select system prompt based on mode
        if mode == "voice":
            system_prompt = config.VOICE_SYSTEM_PROMPT
        elif mode == "sales":
            system_prompt = config.SALES_SYSTEM_PROMPT
        else:
            system_prompt = config.SUPPORT_SYSTEM_PROMPT
        
        self.sessions[session_id] = {
            "mode": mode,
            "history": [],
            "system_prompt": system_prompt,
            "created_at": datetime.now(),
            "last_activity": datetime.now()
        }
        
        return session_id
    
    def add_message(self, session_id: str, role: str, content: str):
        """
        Add a message to conversation history
        
        Args:
            session_id: Session ID
            role: Message role ("user" or "assistant")
            content: Message content
        """
        if session_id not in self.sessions:
            self.create_session(session_id)
        
        session = self.sessions[session_id]
        session["history"].append({"role": role, "content": content})
        session["last_activity"] = datetime.now()
        
        # Trim history if it gets too long
        if len(session["history"]) > config.MAX_HISTORY_MESSAGES:
            # Keep only the most recent messages
            session["history"] = session["history"][-config.MAX_HISTORY_MESSAGES:]
    
    def get_history(self, session_id: str) -> List[Dict]:
        """
        Get conversation history for a session
        
        Args:
            session_id: Session ID
        
        Returns:
            List of message dictionaries
        """
        if session_id not in self.sessions:
            return []
        
        return self.sessions[session_id]["history"].copy()
    
    def get_formatted_history(self, session_id: str) -> str:
        """
        Get conversation history formatted as a prompt string
        
        Args:
            session_id: Session ID
        
        Returns:
            Formatted conversation history
        """
        if session_id not in self.sessions:
            return ""
        
        session = self.sessions[session_id]
        history_text = session["system_prompt"] + "\n\n"
        
        for msg in session["history"]:
            if msg["role"] == "user":
                history_text += f"User: {msg['content']}\n"
            else:
                history_text += f"Assistant: {msg['content']}\n"
        
        history_text += "Assistant: "
        return history_text
    
    def clear_session(self, session_id: str):
        """
        Clear a conversation session
        
        Args:
            session_id: Session ID to clear
        """
        if session_id in self.sessions:
            del self.sessions[session_id]
    
    def cleanup_old_sessions(self):
        """Remove sessions that haven't been active recently"""
        cutoff_time = datetime.now() - timedelta(minutes=config.SESSION_TIMEOUT_MINUTES)
        
        inactive_sessions = [
            session_id 
            for session_id, session in self.sessions.items()
            if session["last_activity"] < cutoff_time
        ]
        
        for session_id in inactive_sessions:
            del self.sessions[session_id]
    
    def get_session_info(self, session_id: str) -> Optional[Dict]:
        """
        Get session metadata
        
        Args:
            session_id: Session ID
        
        Returns:
            Session info dictionary or None
        """
        if session_id not in self.sessions:
            return None
        
        session = self.sessions[session_id]
        return {
            "session_id": session_id,
            "mode": session["mode"],
            "message_count": len(session["history"]),
            "created_at": session["created_at"].isoformat(),
            "last_activity": session["last_activity"].isoformat()
        }
    
    def get_session_mode(self, session_id: str) -> str:
        """Get the mode for a session"""
        if session_id in self.sessions:
            return self.sessions[session_id]["mode"]
        return "support"  # Default


# Global conversation manager instance
conversation_manager = ConversationManager()
