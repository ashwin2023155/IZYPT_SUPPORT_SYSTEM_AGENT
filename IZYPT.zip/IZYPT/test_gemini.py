"""
Test Gemini API integration
"""
from gemini_agent import get_gemini_agent

print("="*70)
print("Testing Gemini API Integration")
print("="*70)

# Initialize Gemini
gemini = get_gemini_agent()

# Test 1: Simple query
print("\n[Test 1] Simple Query")
response1 = gemini.generate("Say hello in one sentence.", max_tokens=50)
print(f"Response: {response1}")

# Test 2: With context (simulating database info)
print("\n[Test 2] With Database Context")
prompt = """You are IZYPT customer support.

Database Information:
Order ID: #ORD-250629-733
Customer: Saroj y
Date: 29/06/2025
Amount: Rs. 1114
Status: CANCELLED

Customer asks: "What's the status of my order?"

Answer briefly and factually:"""

response2 = gemini.generate(prompt, max_tokens=50)
print(f"Response: {response2}")

print("\n" + "="*70)
print("✓ Gemini API is working!")
print("="*70)
